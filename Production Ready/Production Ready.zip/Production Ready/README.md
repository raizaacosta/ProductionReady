## ¿Que es "Production Ready"?
**Production Ready** es el estandar que define la base minima de excelencia operacional que deberia cumplir cualquier equipo en MAPFRE. Define:

- Que hay que cumplir.
- Como documentar y asegurar que se haya cumplido.

Acuerdate que utilizar la carpeta "resources" para tus diagramas (formato draw.io), imagenes y otros artefactos.

##  ¿como lo uso en mi proyecto?
Step 1:
Copia toda la carpeta "Production Ready" en repositorio de tu proyecto.

Step 2:
Cambia el nombre de "Production Ready" por "Documentation"

Step 3:
Añade toda la infromación, diagramas, etc.
