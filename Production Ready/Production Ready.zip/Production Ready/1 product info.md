Información global a alto nivel acerca del producto.   
Punto de entrada principal con datos y referencias a otros documentos de información relevante para obtener un contexto general del producto (owners, contactos, arquitecturas...).

<div><img src="1.png"></div>

---
*High-level global information about the product.  
Main entry point with data and references to other documents of relevant information to obtain a general context of the product (owners, contacts, architectures...).*

### Product Name:
*Name*

### Description:
 *Brief description of product and its objectives*
 
#### Product Owner:
    Name + mail
    
#### Contacts :

 - Area1: Name + mail 
 - Area2: Name + mail
 - .............
 - AreaX: Name + mail
 - DevOps: Name + mail

#### Contact third tools:

(example Rapdminer, IDBox, etc.)
- tool 1: name + mail
- tool 2: name + mail

#### Product documentation

- Link to product book 

#### Architecture

- Link

#### AWS Account:

Environment|Account_Name|Account_ID| 
|---|---|---|
|DEV|---|---|
|QA|---|---|
|PROD|---|---|

#### Repository:

- Repo1: name + link
- Repo2: name + link
- Repo3: name + link  


#### Monitoring:

-  Link to dashboard

#### Releases:

- YYYY/MM/DD + Link
- YYYY/MM/DD + Link
- YYYY/MM/DD + Link

#### Incidences Troubleshooting: 

- Link

#### Operations:

- Task + Link to procedure
- Task + Link to procedure